CADDY 0.9.1

Website
	https://caddyserver.com

Community
	https://forum.caddyserver.com

Twitter
	@caddyserver

Source Code
	https://github.com/mholt/caddy
	https://github.com/caddyserver


For instructions on using Caddy, please see the user guide on
the website. For a list of what's new in this version, see
CHANGES.txt.

The Caddy project accepts pull requests. That means you can make
changes to the code and submit it for review, and if it's good,
we'll use it! You can help thousands of Caddy users and level
up your Go programming game by contributing to Caddy's source.

To report bugs or request features, open an issue on GitHub.

Want to support the project financially? Consider donating,
especially if your company is using Caddy. Believe me, your
contributions do not go unnoticed! We also have sponsorship
opportunities available.

For a good time, follow @mholt6 on Twitter.

And thanks - you're awesome!


---
(c) 2015-2016 Matthew Holt
